<?
//<meta name="wersja" content="0.1.0.1">
//<meta name="zdnia" content="25.09.2022">
//<meta name="info" content="Cennik">


$stawkaplomba=4;
$stawkabmw=4;
$stawkadojazd1=18;


//$czySERW = strpos($tab[devices][otherDevices][0][OTName], "SERW_");
//$czyLEG = strpos($tab[devices][otherDevices][0][OTName], "LEG_");
//$czyOPL = strpos($tab[devices][otherDevices][0][OTName], "OPL_");
//$czyWIN = strpos($tab[devices][otherDevices][0][OTName], "WIN_");

//if ($czySERW) 
//$fazy = '1';

//SERW_1F_
//LEG_
//OPL_
//WIN_

$nazwaczynnosci[2]="Fotografie: Licznik - obowiązkowe";
$stawkaczynnosc[2]=0;
$SERW_1F_stawkaczynnosc[2]=0;
$SERW_3F_stawkaczynnosc[2]=0;
$LEG_1F_stawkaczynnosc[2]=0;
$LEG_3F_stawkaczynnosc[2]=0;
$OPL_1F_stawkaczynnosc[2]=0;
$OPL_3F_stawkaczynnosc[2]=0;
$WIN_1F_stawkaczynnosc[2]=0;
$WIN_3F_stawkaczynnosc[2]=0;

$nazwaczynnosci[3]="Fotografie: plomby - nieobowiazkowe";
$stawkaczynnosc[3]=0;
$SERW_1F_stawkaczynnosc[3]=0;
$SERW_3F_stawkaczynnosc[3]=0;
$LEG_1F_stawkaczynnosc[3]=0;
$LEG_3F_stawkaczynnosc[3]=0;
$OPL_1F_stawkaczynnosc[3]=0;
$OPL_3F_stawkaczynnosc[3]=0;
$WIN_1F_stawkaczynnosc[3]=0;
$WIN_3F_stawkaczynnosc[3]=0;

$nazwaczynnosci[6]="Odczyt stanów liczydeł i danych pomiarowych (NIEOBOWIĄZKOWY przy braku możliwości odczytu)";
$stawkaczynnosc[6]=0;
$SERW_1F_stawkaczynnosc[6]=0;
$SERW_3F_stawkaczynnosc[6]=0;
$LEG_1F_stawkaczynnosc[6]=0;
$LEG_3F_stawkaczynnosc[6]=0;
$OPL_1F_stawkaczynnosc[6]=0;
$OPL_3F_stawkaczynnosc[6]=0;
$WIN_1F_stawkaczynnosc[6]=0;
$WIN_3F_stawkaczynnosc[6]=0;

$nazwaczynnosci[8]="Odlaczenie odbiorcy na wniosek sprzedawcy";
$WIN_1F_stawkaczynnosc[8]=27;
$WIN_3F_stawkaczynnosc[8]=27;




 
$nazwaczynnosci[11]="Ogledziny ogolne";
$stawkaczynnosc[11]=0;

$nazwaczynnosci[12]="Ogledziny - nowa zabudowa";
$stawkaczynnosc[12]=0;

$nazwaczynnosci[13]="Podlaczenie odbiorcy";
$WIN_1F_stawkaczynnosc[13]=12;
$WIN_3F_stawkaczynnosc[13]=12;

$nazwaczynnosci[19]="Sprawdzenie licznika (czynnosci standardowe";
$stawkaczynnosc[19]=0;





$nazwaczynnosci[20]="Sprawdzenie licznika (czynności zaawansowane dla reklamacji)";
$stawkaczynnosc[20]=0;

$nazwaczynnosci[21]="Sprawdzenie licznika ( czynosci zaawansowane dla sprawdzenia";
$stawkaczynnosc[21]=0;

$nazwaczynnosci[25]="Dokonano oględzin instalacji OZE prosumenta";
$stawkaczynnosc[25]=0;





$nazwaczynnosci[30]="Sprawdzenie nowej instalacji elektrycznej / Przeniesienie układu pomiarowego";
$stawkaczynnosc[30]=0;
$nazwaczynnosci[32]="Sprawdzenie/Uruchomienie transmisji GSM";
$stawkaczynnosc[32]=0;

$nazwaczynnosci[33]="Zakonczenie windykacji";
$stawkaczynnosc[33]=0;
//Ogledziny windykacja 

$nazwaczynnosci[36]="Demontaz licznika i powiazanych urzadzenie";
$SERW_1F_stawkaczynnosc[36]=10;
$SERW_3F_stawkaczynnosc[36]=10;
$LEG_1F_stawkaczynnosc[36]=10;
$LEG_3F_stawkaczynnosc[36]=15;
$OPL_1F_stawkaczynnosc[36]=0;
$OPL_3F_stawkaczynnosc[36]=0;
$WIN_1F_stawkaczynnosc[36]=0;
$WIN_3F_stawkaczynnosc[36]=0;






$nazwaczynnosci[43]="Montaz nowego licznika i powiazanych urzadzen";
$stawkaczynnosc[43]=23;
$SERW_1F_stawkaczynnosc[43]=18;
$SERW_3F_stawkaczynnosc[43]=18;
$LEG_1F_stawkaczynnosc[43]=18;
$LEG_3F_stawkaczynnosc[43]=23;
$OPL_1F_stawkaczynnosc[43]=18;
$OPL_3F_stawkaczynnosc[43]=18;
$WIN_1F_stawkaczynnosc[43]=0;
$WIN_3F_stawkaczynnosc[43]=0;

$nazwaczynnosci[44]="Montaz/demontaz oplombowania";
$stawkaczynnosc[44]=0;
$nazwaczynnosci[46]="Odczyt stanow liczydel i danych pomiarowych";
$stawkaczynnosc[46]=3;
$SERW_1F_stawkaczynnosc[46]=3;
$SERW_3F_stawkaczynnosc[46]=3;
$LEG_1F_stawkaczynnosc[46]=3;
$LEG_3F_stawkaczynnosc[46]=3;
$OPL_1F_stawkaczynnosc[46]=3;
$OPL_3F_stawkaczynnosc[46]=3;
$WIN_1F_stawkaczynnosc[46]=3;
$WIN_3F_stawkaczynnosc[46]=3;





$nazwaczynnosci[50]="Sprawdzenie uchybu licznika (licznikiem kontrolnym PWS lub RWM)";
$stawkaczynnosc[50]=18;

$nazwaczynnosci[51]="Sprawdzenie licznika podczas wykonywania OT/OTS Bez napiecia/Pod napieciem/Pod napiecie i obciazeniem";
$stawkaczynnosc[51]=0;

?>
