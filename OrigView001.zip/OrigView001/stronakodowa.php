<?
//<meta name="wersja" content="0.1.1.f">
//<meta name="zdnia" content="28.09.2022">
//<meta name="info" content="Strona kodowa">


//echo '<head><meta http-equiv="content-type" content="text/html; charset=utf-8"></head>';
//echo '<head><meta http-equiv="content-type" content="text/html; charset=ISO-8859-1"></head>';

echo '<head><meta http-equiv="content-type" content="text/html; charset=Windows-1252"></head>';

?>
